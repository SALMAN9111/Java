package com.monocept.model;

public enum AccountStatusType {
	ACTIVE, INACTIVE, BLOCKED;
}
