package com.monocept.model;

public enum TransactionType {
	
	DEPOSIT,WITHDRAW

}
