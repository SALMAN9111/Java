package com.swabhav.jwtapp1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtApp1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
