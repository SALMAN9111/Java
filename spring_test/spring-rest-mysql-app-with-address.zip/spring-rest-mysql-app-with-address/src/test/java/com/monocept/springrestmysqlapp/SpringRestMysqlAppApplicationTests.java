package com.monocept.springrestmysqlapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestMysqlAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
